//
//  PersonManager.m
//  FirstLearningApp
//
//  Created by Lakshmi on 6/1/18.
//  Copyright © 2018 Lakshmi. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "PersonManager.h"


@interface PersonManager(){
    NSArray *iterationArray;
    UIViewController *vcl;
}

@end

@implementation PersonManager

/*-(id)init{
    self = [super init];
    if(self){
        
    }
    return  self;
}
*/
-(void)initWithValue:(NSArray*)objectArray withVc:(UIViewController *)vc{
    iterationArray = objectArray;
    vcl = vc;
    [self navigationBasedonArrayCount:objectArray];
}


-(void)setValueForDict:(NSString*)strFrom{
    self.strPassed = strFrom;
    NSLog(@"log pm %@",self.strPassed);
    
}

-(void)navigationBasedonArrayCount:(NSArray*)array{
    array.count > 3 ? [self navigatetoPush] : [self navigatetoPop];
}

-(void)navigatetoPush{
    
    
}
-(void)navigatetoPop{
    //self.personDelegate = self;
    AlgorithmViewController *ag = [AlgorithmViewController initWithController];
    [vcl.navigationController presentViewController:ag animated:YES completion:nil];
}

-(void)comebackToManager{
    [vcl dismissViewControllerAnimated:YES completion:nil];
}
@end
