//
//  main.m
//  FirstLearningApp
//
//  Created by Lakshmi on 6/1/18.
//  Copyright © 2018 Lakshmi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
