//
//  AlgorithmViewController.h
//  FirstLearningApp
//
//  Created by Lakshmi on 6/1/18.
//  Copyright © 2018 Lakshmi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PersonManager.h"


@interface AlgorithmViewController : UIViewController
+(id)initWithController;


@end
