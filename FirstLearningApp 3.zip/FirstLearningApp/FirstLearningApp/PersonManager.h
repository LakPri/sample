//
//  PersonManager.h
//  FirstLearningApp
//
//  Created by Lakshmi on 6/1/18.
//  Copyright © 2018 Lakshmi. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "AlgorithmViewController.h"

@protocol PersonManagerDelegte
-(void)comebackToManager;
@end

@interface PersonManager : NSObject
@property(nonatomic,strong) NSString *strPassed;
@property(nonatomic,weak) id <PersonManagerDelegte> personDelegate;



-(void)setValueForDict:(NSString*)strFrom;
-(void)initWithValue:(NSArray*)objectArray withVc:(UIViewController *)vc;
@end
