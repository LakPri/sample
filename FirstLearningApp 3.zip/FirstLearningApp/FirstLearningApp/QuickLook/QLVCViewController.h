//
//  QLVCViewController.h
//  FirstLearningApp
//
//  Created by Lakshmi on 11/24/18.
//  Copyright © 2018 Lakshmi. All rights reserved.
//

#import "ViewController.h"
#import "QLView.h"

NS_ASSUME_NONNULL_BEGIN

@interface QLVCViewController : ViewController<QLView>
-(id)controllerWithView;
@end

NS_ASSUME_NONNULL_END
