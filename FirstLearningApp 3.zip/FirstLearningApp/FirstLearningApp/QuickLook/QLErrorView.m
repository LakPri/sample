//
//  QLErrorView.m
//  FirstLearningApp
//
//  Created by Lakshmi on 11/25/18.
//  Copyright © 2018 Lakshmi. All rights reserved.
//

#import "QLErrorView.h"

@implementation QLErrorView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if(self) {
        [self setup];
    }
    return self;
}

- (void)setup {
    [[NSBundle mainBundle] loadNibNamed:@"QLErrorView" owner:self options:nil];
}

@end
