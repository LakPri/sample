//
//  QLPresenter.m
//  FirstLearningApp
//
//  Created by Lakshmi on 11/24/18.
//  Copyright © 2018 Lakshmi. All rights reserved.
//

#import "QLPresenter.h"
#import "QLDataSource.h"
#import "QLModel.h"

@interface QLPresenter()
@property (nonatomic, strong) NSURL *pdfUrl;
@property (nonatomic, strong) id<QLView>  viewDelegate;
@property (strong, nonatomic) QLDataSource *pdfDatasource;
@property (nonatomic, strong) QLModel * model;
@property (nonatomic, strong) QLPreviewController *qlController;
@end

@implementation QLPresenter
-(id)initWithView:(id<QLView>) view withURL:(NSURL *) url{
    
    if(self = [super init]){
        self.pdfUrl = url;
        self.viewDelegate = view;
    }
    return self;
}

-(void)downLoadPdf{
    self.qlController = [[QLPreviewController alloc] init];

    self.model = [[QLModel alloc] initPreviewURL:self.pdfUrl WithTitle:@"Hello" withDownload:self] ;
    
 
}

-(void)onSuccess{
    self.pdfDatasource = [[QLDataSource alloc] initWithPreviewItem:self.model];
    self.qlController.dataSource = self.pdfDatasource;
    
    [self.viewDelegate loadPDF:self.qlController withDataSource:self.pdfDatasource];
   // [self.viewDelegate loadPDFByModel:self.model];
}
@end
