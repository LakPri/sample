//
//  QLDataSource.h
//  FirstLearningApp
//
//  Created by Lakshmi on 11/24/18.
//  Copyright © 2018 Lakshmi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QLModel.h"
@import QuickLook;

NS_ASSUME_NONNULL_BEGIN

@interface QLDataSource : NSObject<QLPreviewControllerDataSource>
@property (strong, nonatomic) QLModel *item;
- (instancetype)initWithPreviewItem:(QLModel *)item;
@end

NS_ASSUME_NONNULL_END
