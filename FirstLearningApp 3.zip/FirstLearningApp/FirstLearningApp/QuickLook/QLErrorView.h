//
//  QLErrorView.h
//  FirstLearningApp
//
//  Created by Lakshmi on 11/25/18.
//  Copyright © 2018 Lakshmi. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface QLErrorView : UIView
@property (weak, nonatomic) IBOutlet UILabel *lblError;
@property (weak, nonatomic) IBOutlet UILabel *lblInstruction;

@end

NS_ASSUME_NONNULL_END
