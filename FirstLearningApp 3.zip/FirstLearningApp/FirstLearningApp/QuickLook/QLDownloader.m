//
//  QLDownloader.m
//  FirstLearningApp
//
//  Created by Lakshmi on 11/24/18.
//  Copyright © 2018 Lakshmi. All rights reserved.
//

#import "QLDownloader.h"
#import "QLModel.h"


@interface QLDownloader()
@property (nonatomic, strong) NSURL *pdfUrl;
@end

@implementation QLDownloader

-(id)initWithUrl:(NSURL *)url{
    if(self = [super init]){
        _pdfUrl = url;
    }
    return self;
}

- (void)getPdfFromUrlWithCompletionHandler:(void(^)(NSString *  urlPath, NSError *error)) completion{
    
    NSString * pdfPathComponent = [_pdfUrl lastPathComponent];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:_pdfUrl];
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request
                                            completionHandler:
                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
                                      dispatch_async(dispatch_get_main_queue(), ^{
                                      if(data){
                                          NSArray *paths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
                                          NSString *documentDirectory=[paths objectAtIndex:0];
                                          
                                          NSString *finalPath=[documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat: @"%@", pdfPathComponent]]; //check your path correctly and provide your name dynamically
                                          NSLog(@"finalpath--%@",finalPath);

                                         [data writeToFile:finalPath atomically:YES];
                                          completion(finalPath, nil);
                                      }else{
                                          completion(nil, [NSError new]);
                                      }
                                     });
                                  }];
    
    [task resume];
}
@end
