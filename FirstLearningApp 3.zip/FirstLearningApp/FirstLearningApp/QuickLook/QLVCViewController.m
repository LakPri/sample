//
//  QLVCViewController.m
//  FirstLearningApp
//
//  Created by Lakshmi on 11/24/18.
//  Copyright © 2018 Lakshmi. All rights reserved.
//

#import "QLVCViewController.h"
#import  "QLPresenter.h"
#import "QLDataSource.h"
#import "QLErrorView.h"

@interface QLVCViewController ()
@property (nonatomic, strong) QLPresenter * presenter;
@property (nonatomic, strong) QLDataSource * pdfDataSource;
@property (nonatomic, strong) QLErrorView *errorView;

@end

@implementation QLVCViewController

-(id)controllerWithView{
    return [[QLVCViewController alloc] init];//WithNibName:@"QLVCViewController" bundle:nil];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
  /* self.presenter = [[QLPresenter alloc]initWithView:self withURL:[NSURL URLWithString:@"https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf"]];
    [self.presenter downLoadPdf];*/
    self.navigationController.navigationBar.hidden = YES;
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    self.presenter = [[QLPresenter alloc]initWithView:self withURL:[NSURL URLWithString:@"https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf"]];
    [self.presenter downLoadPdf];
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}


- (void)hideLoading {
    
}

- (void)loadPDF:(QLPreviewController *)vc withDataSource:(id)dataSource {
 //  vc.dataSource = dataSource;
  //  [vc reloadData];
    
    [self addChildViewController:vc];

    CGFloat width = self.view.frame.size.width;
    CGFloat height = self.view.frame.size.height;
    vc.view.frame = CGRectMake(0, 0, width, height);
    [self.view addSubview:vc.view];
    [vc didMoveToParentViewController:self];
    //[vc.view setNeedsDisplay];
    //[vc reloadData];
    
   /* [self addChildViewController:vc];
    [self.view addSubview:vc.view];
    [vc didMoveToParentViewController:self];
    [vc reloadData];*/
    

    
    
 //[self.navigationController pushViewController:vc animated:NO];
}

- (void)showError {
    
 /*   self.errorView = [[QLErrorView alloc]init];
    self.errorView.lblError.text = @"Hello i am herecsdssf";
    [self.view addSubview:self.errorView];
    
   /* UILabel *lbErrormsg = [[UILabel alloc]initWithFrame:CGRectMake(10, 40, 300, 200)];
    lbErrormsg.text = @"Hello i am herer";
    [self.view addSubview:lbErrormsg];*/
}

- (void)showLoading {
    
}
-(void)loadPDFByModel:(QLModel *)model{
    
   QLPreviewController *qlController = [[QLPreviewController alloc] init];
    self.pdfDataSource = [[QLDataSource alloc] initWithPreviewItem:model];
    qlController.dataSource = self.pdfDataSource;
   [self addChildViewController:qlController];
    CGFloat width = self.view.frame.size.width;
    CGFloat height = self.view.frame.size.height;
    qlController.view.frame = CGRectMake(0, 0, width, height);
    [self.view addSubview:qlController.view];
    [qlController didMoveToParentViewController:self];
  //[qlController reloadData];
  
    
 // [self.navigationController pushViewController:qlController animated:NO];

}
@end



