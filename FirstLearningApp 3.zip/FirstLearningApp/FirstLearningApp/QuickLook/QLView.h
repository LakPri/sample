//
//  QLView.h
//  FirstLearningApp
//
//  Created by Lakshmi on 11/24/18.
//  Copyright © 2018 Lakshmi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "QLModel.h"
#import "QLDataSource.h"
NS_ASSUME_NONNULL_BEGIN

@protocol QLView <NSObject>

-(void)showLoading;
-(void)hideLoading;
-(void)showError;
-(void)loadPDF:(QLPreviewController *)vc withDataSource:(QLDataSource *)dataSource;

-(void)loadPDFByModel:(QLModel *)model;


@end
NS_ASSUME_NONNULL_END
