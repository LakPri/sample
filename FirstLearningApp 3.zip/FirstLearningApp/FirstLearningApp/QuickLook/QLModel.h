//
//  QLModel.h
//  FirstLearningApp
//
//  Created by Lakshmi on 11/24/18.
//  Copyright © 2018 Lakshmi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import  "QLDownloadProtocol.h"

@import QuickLook;

NS_ASSUME_NONNULL_BEGIN

@interface QLModel : NSObject <QLPreviewItem>
@property(readonly, nullable, nonatomic) NSURL      * previewItemURL;
@property(readonly, nullable, nonatomic) NSString   * previewItemTitle;
@property (nonatomic, strong) id<QLDownloadProtocol> downloadDelegate;

- (instancetype)initPreviewURL:(NSURL *)docURL WithTitle:(NSString *)title withDownload:(id<QLDownloadProtocol>) downloadDelegate;
@end

NS_ASSUME_NONNULL_END
