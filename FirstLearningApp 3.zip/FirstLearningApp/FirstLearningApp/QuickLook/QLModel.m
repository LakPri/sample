//
//  QLModel.m
//  FirstLearningApp
//
//  Created by Lakshmi on 11/24/18.
//  Copyright © 2018 Lakshmi. All rights reserved.
//

#import "QLModel.h"
#import "QLDownloader.h"

@implementation QLModel
- (instancetype)initPreviewURL:(NSURL *)docURL WithTitle:(NSString *)title withDownload:(nonnull id<QLDownloadProtocol>)downloadDelegate {
    self = [super init];
    if (self) {
        _previewItemURL = [docURL copy];
        _previewItemTitle = [title copy];
        self.downloadDelegate = downloadDelegate;
        [self updateDownloadedPath];
    }
    return self;
}

-(void)updateDownloadedPath{
    
    NSString * pdfPathComponent = [self.previewItemURL lastPathComponent];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:_previewItemURL];
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request
                                            completionHandler:
                                  ^(NSData *data, NSURLResponse *response, NSError *error) {
                                      dispatch_async(dispatch_get_main_queue(), ^{
                                      if(data){
                                          NSArray *paths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
                                          NSString *documentDirectory=[paths objectAtIndex:0];
                                          
                                          NSString *finalPath=[documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat: @"%@", pdfPathComponent]]; //check your path correctly and provide your name dynamically
                                          NSLog(@"finalpath--%@",finalPath);
                                          
                                          [data writeToFile:finalPath atomically:YES];
                                          _previewItemURL = [NSURL fileURLWithPath:finalPath];
                                          [self.downloadDelegate onSuccess];
                                      }
                                      });
                                  }];
    
    [task resume];

    
  /*  QLDownloader *downloader = [[QLDownloader alloc] initWithUrl:_previewItemURL];
    [downloader getPdfFromUrlWithCompletionHandler:^(NSString *  urlPath, NSError * _Nonnull error) {
        if(urlPath){
            self->_previewItemURL = [NSURL fileURLWithPath:urlPath];
        }
    }];*/
}

@end
