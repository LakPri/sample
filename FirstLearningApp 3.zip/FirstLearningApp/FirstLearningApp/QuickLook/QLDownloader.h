//
//  QLDownloader.h
//  FirstLearningApp
//
//  Created by Lakshmi on 11/24/18.
//  Copyright © 2018 Lakshmi. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface QLDownloader : NSObject
-(id)initWithUrl:(NSURL *)url;
- (void)getPdfFromUrlWithCompletionHandler:(void(^)(NSString *  urlPath, NSError *error)) completion;

@end

NS_ASSUME_NONNULL_END
