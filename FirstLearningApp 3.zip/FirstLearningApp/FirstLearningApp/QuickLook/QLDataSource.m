//
//  QLDataSource.m
//  FirstLearningApp
//
//  Created by Lakshmi on 11/24/18.
//  Copyright © 2018 Lakshmi. All rights reserved.
//

#import "QLDataSource.h"

@implementation QLDataSource
- (instancetype)initWithPreviewItem:(QLModel *)item {
    self = [super init];
    if (self) {
        _item = item;
    }
    return self;
}

- (NSInteger)numberOfPreviewItemsInPreviewController:(nonnull QLPreviewController *)controller {
    return 1;

}

- (nonnull id<QLPreviewItem>)previewController:(nonnull QLPreviewController *)controller previewItemAtIndex:(NSInteger)index {
    return self.item;
}

@end
