//
//  QLPresenter.h
//  FirstLearningApp
//
//  Created by Lakshmi on 11/24/18.
//  Copyright © 2018 Lakshmi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QLView.h"
NS_ASSUME_NONNULL_BEGIN



@interface QLPresenter : NSObject<QLDownloadProtocol>
-(id)initWithView:(id<QLView>) view withURL:(NSURL *) url;
-(void)downLoadPdf;
@end

NS_ASSUME_NONNULL_END
