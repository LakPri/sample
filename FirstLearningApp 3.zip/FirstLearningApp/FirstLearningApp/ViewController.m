//
//  ViewController.m
//  FirstLearningApp
//
//  Created by Lakshmi on 6/1/18.
//  Copyright © 2018 Lakshmi. All rights reserved.
//

#import "ViewController.h"
#import "PersonManager.h"
#import "QLVCViewController.h"

#define OPTIONMAP  @[@"Hello",@"Honey"]

#define ARRAY1  @[@1,@2,@5,@4]

#define ARRAY2  @[@3,@2,@4]



@interface ViewController ()
{
    NSMutableDictionary *userDictionary;
}
@property (nonatomic, strong) QLVCViewController *vc;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
   
}
- (IBAction)pushAlgorithmView:(id)sender {
    userDictionary = [@{@"Hello":@"1",@"Hai":@"2",@"Honey":@"3"} mutableCopy];
    
   
  //  n*n algoritm
   /* for (NSString *key in userDictionary.allKeys){
        BOOL checkKeys = false;
        for(int i = 0; i < OPTIONMAP.count; i++){
            
            if([key isEqualToString:[OPTIONMAP objectAtIndex:i]]){
                checkKeys = YES;
            }
            NSLog(@"Keys:%@",userDictionary);
            
        }if(!checkKeys)
            [userDictionary removeObjectForKey:key];
        NSLog(@"Keys:%@",userDictionary);
        
        
    }*/
    
    for(int i=0; i < ARRAY1.count; i++){
        for(int j=0; j<ARRAY2.count; j++){
            if(![[ARRAY1 objectAtIndex:i]integerValue] + [[ARRAY2 objectAtIndex:j]integerValue] == 8){
                NSLog(@"Sum of number is : %ld%ld",(long)[[ARRAY1 objectAtIndex:i]integerValue],(long)[[ARRAY2 objectAtIndex:j]integerValue] );
            }
        }
    }
        
    
/*-----------------------------------------------------------*/
/*-----------------------------------------------------------*/

    /* o(n)*/
    
  /*  NSArray *temparray = [userDictionary allKeys];
    NSLog(@"%@",temparray);

    NSMutableArray *removeObject = [[NSMutableArray alloc]init];
    
    for (NSString *key in userDictionary.allKeys)
    {
        if (![OPTIONMAP containsObject:key])
        {
            [removeObject addObject:key];
        }
    }
    
    
    for(int i=0; i<temparray.count ; i++){
        NSLog(@"%@",temparray[i]);

        if(![OPTIONMAP containsObject:temparray[i]]){
            [removeObject addObject:(NSString*)temparray[i]];
        }
    }
    
    
    
    NSLog(@"%@",removeObject);

    [userDictionary removeObjectsForKeys:removeObject];
    
    NSLog(@"%@",userDictionary);*/
    
    /*-----------------------------------------------------------*/
    /*-----------------------------------------------------------*/
    /*-----------------------------------------------------------*/

    
}
- (IBAction)btnFactoryPattern:(id)sender {
   // [[PersonManager alloc]initWithValue:(NSArray*)OPTIONMAP];
    self.vc = [[QLVCViewController alloc] controllerWithView];
    [self.navigationController pushViewController:self.vc animated:YES];
  
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)calltoManager{
    
}


@end
