//
//  AlgorithmViewController.m
//  FirstLearningApp
//
//  Created by Lakshmi on 6/1/18.
//  Copyright © 2018 Lakshmi. All rights reserved.
//

#import "AlgorithmViewController.h"
#import "PersonManager.h"



@interface AlgorithmViewController (){
}
@property (nonatomic,weak) PersonManager *personmgr;
@end

@implementation AlgorithmViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
   
    // Do any additional setup after loading the view from its nib.
}


+(id)initWithController{
    
    return [[AlgorithmViewController alloc] initWithNibName:@"AlgorithmViewController" bundle:nil];

}


- (IBAction)btnGoBack:(id)sender {
    _personmgr =[[PersonManager alloc]init];
    _personmgr.personDelegate =self;
   // [_personmgr  comebackToManager];

   }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
